package curs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KursovApplication {

    public static void main(String[] args) {
        SpringApplication.run(KursovApplication.class, args);
    }

}
