package curs.repo;

public interface JoinCompanyRequestRepository extends JpaRepository<JoinCompanyRequest, Long> {
    List<JoinCompanyRequest> findAllByApprovedFalse();
}

