package curs.model.enums;

public enum CompanyRequestStatus {
    PENDING,
    APPROVED,
    REJECTED
}
