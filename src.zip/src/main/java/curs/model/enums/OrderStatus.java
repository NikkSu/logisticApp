package curs.model.enums;

public enum OrderStatus {
    CREATED, SENT, RECEIVED, CANCELLED
}
