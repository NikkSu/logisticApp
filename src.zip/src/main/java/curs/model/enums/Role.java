package curs.model.enums;

public enum Role {
    ADMIN,
    USER,
    SUPPLIER
}