package curs.model.enums;

public enum SupplierStatus {
    PENDING,
    APPROVED,
    REJECTED
}
