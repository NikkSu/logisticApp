package curs.mapper;

import curs.model.Supplier;
import curs.dto.SupplierDTO;

public class SupplierMapper {
    public static Supplier toEntity(SupplierDTO dto) {
        Supplier s = new Supplier();
        s.setId(dto.getId());
        s.setName(dto.getName());
        s.setAddress(dto.getAddress());
        s.setContactEmail(dto.getContactEmail());
        s.setPhone(dto.getPhone());
        return s;
    }

    public static SupplierDTO toDTO(Supplier s) {
        SupplierDTO dto = new SupplierDTO();
        dto.setId(s.getId());
        dto.setName(s.getName());
        dto.setAddress(s.getAddress());
        dto.setContactEmail(s.getContactEmail());
        dto.setPhone(s.getPhone());
        return dto;
    }
}
