import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import AuthForm from "./components/AuthPage";
import ForgotPasswordForm from "./components/ForgotPasswordForm";

export default function App() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Navigate to="/auth" />} />

                <Route path="/auth" element={<AuthForm />} />
                <Route path="/forgot-password" element={<ForgotPasswordForm />} />
            </Routes>
        </Router>
    );
}
