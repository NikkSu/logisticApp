import React, { useState } from "react";
import axios from "axios";

export default function ForgotPassword() {
    const [email, setEmail] = useState("");
    const [message, setMessage] = useState("");

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post("http://localhost:8080/api/auth/forgot-password", { email });
            setMessage("✅ Новый пароль отправлен на вашу почту!");
        } catch (err) {
            setMessage("⚠️ Ошибка: не удалось отправить письмо");
        }
    };

    return (
        <div className="auth-container">
            <h2>Восстановление пароля</h2>
            <form className="auth-form" onSubmit={handleSubmit}>
                <input
                    type="email"
                    className="auth-input"
                    placeholder="Введите свой Email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                />
                <button type="submit" className="auth-submit">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path d="M10 17l5-5-5-5v10z" />
                    </svg>
                </button>
            </form>
            {message && <p className="auth-message">{message}</p>}
        </div>
    );
}
