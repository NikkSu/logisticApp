import React from "react";
import { useForm } from "react-hook-form";
import { loginUser } from "../api/auth"; // твой API вызов

export default function LoginForm() {
    const {
        register,
        handleSubmit,
        formState: { errors, isSubmitting },
    } = useForm();

    const onSubmit = async (data) => {
        console.log("Отправляем логин:", data);
        try {
            const result = await loginUser(data);
            console.log("Ответ сервера:", result);

            if (result?.token) {
                alert("✅ Успешный вход!");
                // пример: localStorage.setItem("token", result.token);
                // и можно редиректить, если нужно
            } else {
                alert("❌ Неверный логин или пароль");
            }
        } catch (error) {
            console.error("Ошибка при логине:", error);
            alert("⚠️ Не удалось подключиться к серверу");
        }
    };

    return (
        <form className="auth-form auth-login-form" onSubmit={handleSubmit(onSubmit)}>
            <div className="auth-input-group">
                <input
                    className={`auth-input ${errors.email ? "error" : ""}`}
                    type="email"
                    placeholder="Email"
                    {...register("email", {
                        required: "Введите email",
                        pattern: { value: /^\S+@\S+\.\S+$/, message: "Некорректный email" },
                    })}
                />
                <p className="auth-error">{errors.email?.message}</p>
            </div>

            <div className="auth-input-group">
                <input
                    className={`auth-input ${errors.password ? "error" : ""}`}
                    type="password"
                    placeholder="Пароль"
                    {...register("password", {
                        required: "Введите пароль",
                        minLength: { value: 6, message: "Минимум 6 символов" },
                    })}
                />
                <p className="auth-error">{errors.password?.message}</p>
            </div>

            <a href="/forgot-password" className="forgot-password">
                Забыли пароль?
            </a>

            <button type="submit" className="auth-submit" disabled={isSubmitting}>
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path d="M10 17l5-5-5-5v10z" />
                </svg>
            </button>

            <div className="social-buttons">
                <button type="button" className="social-btn discord">
                    <img src="/images/discord.svg" alt="Discord" />
                </button>
                <button type="button" className="social-btn google">
                    <img src="/images/google.svg" alt="Google" />
                </button>
            </div>
        </form>
    );
}
