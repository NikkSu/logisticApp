import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { useNavigate } from "react-router-dom";
import "../styles/auth.css";


const loginSchema = yup.object().shape({
    email: yup.string().email("Введите корректный email").required("Введите email"),
    password: yup.string().required("Введите пароль"),
});

const registerSchema = yup.object().shape({
    username: yup.string().min(3, "Имя должно быть не короче 3 символов").required("Введите имя пользователя"),
    email: yup.string().email("Введите корректный email").required("Введите email"),
    password: yup.string().min(6, "Минимум 6 символов").required("Введите пароль"),
});

export default function AuthForm() {
    const [mode, setMode] = useState("login"); // login | register
    const navigate = useNavigate();

    const schema = mode === "login" ? loginSchema : registerSchema;
    const {
        register,
        handleSubmit,
        formState: { errors },
    } = useForm({ resolver: yupResolver(schema) });

    const onSubmit = (data) => {
        console.log("Форма:", mode, data);
    };

    return (
        <div className="auth-container">
            {/* === Тоггл === */}
            <div className="auth-toggle">
                <div
                    className={`toggle-indicator ${mode === "register" ? "right" : ""}`}
                ></div>
                <div
                    className={`toggle-btn ${mode === "login" ? "active" : ""}`}
                    onClick={() => setMode("login")}
                >
                    Вход
                </div>
                <div
                    className={`toggle-btn ${mode === "register" ? "active" : ""}`}
                    onClick={() => setMode("register")}
                >
                    Регистрация
                </div>
            </div>

            <form className="auth-form" onSubmit={handleSubmit(onSubmit)}>
                {mode === "register" && (
                    <>
                        <input
                            className={`auth-input ${errors.username ? "error" : ""}`}
                            placeholder="Имя пользователя"
                            {...register("username")}
                        />
                        {errors.username && (
                            <p className="auth-error">{errors.username.message}</p>
                        )}
                    </>
                )}

                <input
                    className={`auth-input ${errors.email ? "error" : ""}`}
                    placeholder="Email"
                    type="email"
                    {...register("email")}
                />
                {errors.email && <p className="auth-error">{errors.email.message}</p>}

                <input
                    className={`auth-input ${errors.password ? "error" : ""}`}
                    placeholder="Пароль"
                    type="password"
                    {...register("password")}
                />
                {errors.password && (
                    <p className="auth-error">{errors.password.message}</p>
                )}

                {/* === Кнопка входа/регистрации === */}
                <button type="submit" className="auth-submit">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <path d="M10 17l5-5-5-5v10z"/>
                    </svg>
                </button>

                {/* === Кнопки соцсетей === */}
                <div className="social-buttons">
                    <button className="social-btn discord">
                        <img src="/images/discord.svg" alt="Discord"/>
                    </button>
                    <button className="social-btn google">
                        <img src="/images/google.svg" alt="Google"/>
                    </button>
                </div>

                {mode === "login" && (
                    <p
                        className="forgot-password"
                        onClick={() => navigate("/forgot-password")}
                    >
                        Забыли пароль?
                    </p>
                )}
            </form>
        </div>
    );
}
